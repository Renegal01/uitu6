import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function Messenger() {
  const [messages, setMessages] = useState([]);
  const [users, setUsers] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetchMessages();
    fetchUsers();
  }, []);

  const fetchMessages = async () => {
    try {
      const response = await axios.get("http://127.0.0.1:5000/messages");
      setMessages(response.data);
    } catch (error) {
      console.error("Ошибка загрузки сообщений:", error);
    }
  };

  const fetchUsers = async () => {
    try {
      const response = await axios.get("http://127.0.0.1:5000/users");
      setUsers(response.data);
    } catch (error) {
      console.error("Ошибка загрузки пользователей:", error);
    }
  };

  const getFioById = (userId) => {
    const user = users.find((u) => u.id === userId);
    return user ? user.fio : "Неизвестный пользователь";
  };

  const handleOpenFullMessage = (message) => {
    const messageWindow = window.open("", "_blank", "width=600,height=400");
    if (messageWindow) {
      messageWindow.document.write(`
        <html>
          <head>
            <title>Детали сообщения</title>
          </head>
          <body>
            <h3>Детали сообщения</h3>
            <p><strong>Отправитель:</strong> ${getFioById(message.sender_id)}</p>
            <p><strong>Получатель:</strong> ${getFioById(message.receiver_id)}</p>
            <p><strong>Тема:</strong> ${message.subject || "Без темы"}</p>
            <p><strong>Сообщение:</strong> ${message.message}</p>
            <button onclick="window.close()">Закрыть</button>
          </body>
        </html>
      `);
    }
  };

  const handleDeleteMessage = async (id) => {
    const confirmDelete = window.confirm("Вы уверены, что хотите удалить сообщение?");
    if (!confirmDelete) return;

    try {
      await axios.delete(`http://127.0.0.1:5000/messages/${id}`);
      alert("Сообщение удалено");
      setMessages(messages.filter((msg) => msg.id !== id));
    } catch (error) {
      console.error("Ошибка удаления сообщения:", error);
      alert("Не удалось удалить сообщение");
    }
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>Мессенджер</h2>
      <div style={{ marginBottom: "20px" }}>
        <button
          onClick={() => navigate("/new-message")}
          style={{
            padding: "10px 20px",
            backgroundColor: "#007bff",
            color: "white",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
          }}
        >
          Добавить сообщение
        </button>
      </div>
      <table
        style={{
          width: "100%",
          borderCollapse: "collapse",
          marginBottom: "20px",
        }}
      >
        <thead>
          <tr>
            <th style={{ border: "1px solid black", padding: "10px" }}>ID</th>
            <th style={{ border: "1px solid black", padding: "10px" }}>Отправитель</th>
            <th style={{ border: "1px solid black", padding: "10px" }}>Получатель</th>
            <th style={{ border: "1px solid black", padding: "10px" }}>Тема</th>
            <th style={{ border: "1px solid black", padding: "10px" }}>Действия</th>
          </tr>
        </thead>
        <tbody>
          {messages.map((msg) => (
            <tr key={msg.id}>
              <td style={{ border: "1px solid black", padding: "10px" }}>{msg.id}</td>
              <td style={{ border: "1px solid black", padding: "10px" }}>
                {getFioById(msg.sender_id)}
              </td>
              <td style={{ border: "1px solid black", padding: "10px" }}>
                {getFioById(msg.receiver_id)}
              </td>
              <td style={{ border: "1px solid black", padding: "10px" }}>
                {msg.subject || "Без темы"}
              </td>
              <td style={{ border: "1px solid black", padding: "10px" }}>
                <button
                  onClick={() => handleOpenFullMessage(msg)}
                  style={{
                    padding: "5px 10px",
                    backgroundColor: "#007bff",
                    color: "white",
                    border: "none",
                    cursor: "pointer",
                    borderRadius: "3px",
                    marginRight: "5px",
                  }}
                >
                  Полный просмотр
                </button>
                <button
                  onClick={() => handleDeleteMessage(msg.id)}
                  style={{
                    padding: "5px 10px",
                    backgroundColor: "#dc3545",
                    color: "white",
                    border: "none",
                    cursor: "pointer",
                    borderRadius: "3px",
                  }}
                >
                  Удалить
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Messenger;
